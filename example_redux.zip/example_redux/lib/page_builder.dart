import 'package:flutter/widgets.dart';

typedef QABuilder = Widget Function(BuildContext context);